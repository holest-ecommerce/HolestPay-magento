var config = {
    map: {
        '*': {
            holestpayFrontend: 'HEC_HolestPay/js/holestpay-frontend'
        }
    },
    paths: {
        'HEC_HolestPay/js/view/payment/method-renderer/holestpay': 'HEC_HolestPay/js/view/payment/method-renderer/holestpay'
    }
};


