var config = {
    map: {
        '*': {
            holestpayAdmin: 'HEC_HolestPay/js/holestpay-admin'
        }
    }
};


